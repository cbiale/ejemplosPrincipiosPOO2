# SOLID Examples
How to apply de SOLID principles

## Utilities
* Maven

## SOLID
* Single responsibility principle
* Open–closed principle
* Liskov substitution principle
* Interface segregation principle
* Dependency inversion principle


Visit [eduesqui.com](https://eduesqui.com) 
