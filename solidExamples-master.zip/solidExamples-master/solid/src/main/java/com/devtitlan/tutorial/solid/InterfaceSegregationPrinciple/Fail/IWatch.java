package com.devtitlan.tutorial.solid.InterfaceSegregationPrinciple.Fail;

public interface IWatch {
	public String getTime();
	public String getEmailNotifications() throws Exception;
	
}
