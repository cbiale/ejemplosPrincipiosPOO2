package com.devtitlan.tutorial.solid.singleResponsibilityPrinciple;

public class PrintResult {

	public String printAsHtml(Double result) {
		return "<h1>Result:</h1><p>The areas is "+result+"</p>";
	}
}
