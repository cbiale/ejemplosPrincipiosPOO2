package com.devtitlan.tutorial.solid.openClosePrinciple;

public interface IShape {

	public Double getArea();
}
