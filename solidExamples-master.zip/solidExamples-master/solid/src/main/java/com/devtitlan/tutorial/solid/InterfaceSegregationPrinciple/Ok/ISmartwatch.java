package com.devtitlan.tutorial.solid.InterfaceSegregationPrinciple.Ok;

public interface ISmartwatch extends ISimpleWatch {

	public String getEmailNotifications() throws Exception;
}
