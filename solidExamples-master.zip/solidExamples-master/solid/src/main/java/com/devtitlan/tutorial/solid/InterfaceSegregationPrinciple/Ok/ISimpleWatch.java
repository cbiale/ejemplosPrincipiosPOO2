package com.devtitlan.tutorial.solid.InterfaceSegregationPrinciple.Ok;

import java.util.function.IntSupplier;

public interface ISimpleWatch {

	public String getTime();

}
