package com.devtitlan.tutorial.solid.liskovSubstitutionPrincipleR.liskovOk;

public interface ILesson {
	
	public double calculateScore(double homework, double exam);

}
