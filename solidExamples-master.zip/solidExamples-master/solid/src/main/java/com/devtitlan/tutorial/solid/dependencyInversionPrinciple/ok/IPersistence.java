package com.devtitlan.tutorial.solid.dependencyInversionPrinciple.ok;

public interface IPersistence {
	
	public void save(Object object);
	
	
}
